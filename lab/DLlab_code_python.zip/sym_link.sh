#!/bin/bash
mkdir -p ~/.keras/models
ln -sf /it/student/sml/vgg16_weights_tf_dim_ordering_tf_kernels.h5 ~/.keras/models/vgg16_weights_tf_dim_ordering_tf_kernels.h5
